const campaigns = [
  {
    id: '1',
    name: 'H?c vi�n sinh nh?t th�ng 8',
    branch_id: 'T?t c?',
    status: '�ang ch?y',
    internal_campaign_tasks: [
      { students: { branch_id: 'Vi?t Tr� 1' } }
    ]
  }
];

const filterStatus = "T?t c?";
const filterBranch = "L�m Thao";

const displayedCampaigns = campaigns
    .map(camp => {
      let tasks = camp.internal_campaign_tasks || [];
      if (filterBranch !== "T?t c?") {
        tasks = tasks.filter((t) => t.students?.branch_id?.includes(filterBranch));
      }
      return { ...camp, filtered_tasks: tasks };
    })
    .filter(c => {
      const matchStatus = filterStatus === "T?t c?" || c.status === filterStatus;
      if (!matchStatus) return false;
      if (filterBranch === "T?t c?") return true;
      return c.filtered_tasks.length > 0 || c.branch_id.includes(filterBranch);
    });

console.log(JSON.stringify(displayedCampaigns, null, 2));
